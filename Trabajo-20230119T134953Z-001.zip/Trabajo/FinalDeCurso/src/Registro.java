import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import com.sendemail.SendMail;
import com.sendemail.Validar;

public class Registro extends JFrame {

	private JPanel contentPane;
	private JTextField txtUser;
	private JTextField txtMail;
	private JPasswordField txtPass;
	static String nick;
	static String mail;
	static String pass;
	static String pass2;
	static int img = 1;
	static JCheckBox chckbxTerms;
	private JPasswordField txtPass2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registro frame = new Registro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private void cargarDriver() {
	    try {
	      Class.forName("com.mysql.jdbc.Driver");
	    }catch(Exception ex) {
	      setTitle(ex.toString());
	    }
	  }
	
	/**
	 * Create the frame.
	 */
	public Registro() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin-dam1b\\Desktop\\Trabajo\\FinalDeCurso\\assets\\logo.png"));
		cargarDriver();
		setTitle("Pregunta2");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 986, 582);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(239, 184, 16));
		panel.setBounds(0, 0, 970, 128);
		contentPane.add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(239, 184, 16));
		panel_1.setBounds(90, 11, 822, 110);
		panel.add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("REGISTRO");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setFont(new Font("Ravie", Font.PLAIN, 99));
		lblNewLabel_1.setBounds(64, 11, 695, 132);
		panel_1.add(lblNewLabel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		panel_2.setBackground(new Color(0, 51, 102));
		panel_2.setBounds(0, 122, 970, 421);
		contentPane.add(panel_2);
		
		JLabel lblNick = new JLabel("Nick");
		lblNick.setForeground(Color.WHITE);
		lblNick.setFont(new Font("Ravie", Font.PLAIN, 20));
		lblNick.setBounds(124, 75, 59, 27);
		panel_2.add(lblNick);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setForeground(Color.WHITE);
		lblEmail.setFont(new Font("Ravie", Font.PLAIN, 20));
		lblEmail.setBounds(124, 113, 76, 27);
		panel_2.add(lblEmail);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(Color.WHITE);
		lblPassword.setFont(new Font("Ravie", Font.PLAIN, 20));
		lblPassword.setBounds(124, 151, 131, 27);
		panel_2.add(lblPassword);
		
		txtUser = new JTextField();
		txtUser.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtUser.setColumns(10);
		txtUser.setBounds(265, 75, 176, 25);
		panel_2.add(txtUser);
		
		txtMail = new JTextField();
		txtMail.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtMail.setColumns(10);
		txtMail.setBounds(265, 113, 176, 25);
		panel_2.add(txtMail);
		
		JButton btnRegister = new JButton("Registrarse");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				nick = txtUser.getText();
				mail = txtMail.getText();
				pass = String.valueOf(txtPass.getPassword());
				pass2 = String.valueOf(txtPass2.getPassword());
				boolean enviar = Validar.validacion(mail);
				
		        try {
		        	Connection connect=DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
		        	Statement name=connect.createStatement();
					ResultSet usuario = name.executeQuery("select count(id) from usuarios where nick like '" + nick + "';");
					usuario.next();
					int user = usuario.getInt(1);
					ResultSet correo = name.executeQuery("select count(id) from usuarios where email like '" + mail + "';");
					correo.next();
					int email = correo.getInt(1);
					if (nick.equals("") || mail.equals("") || pass.equals("") || pass2.equals("")) {
						JOptionPane.showMessageDialog(null, "Uno o m�s campos est�n vacios", "Campos sin rellenar", 0, null);
					} else if (!pass2.equals(pass)) {
						JOptionPane.showMessageDialog(null, "Las contrase�as no coinciden. Intentelo de nuevo", "Contrase�as incorrectas", 0, null);
						txtPass2.setText("");
					} else if (!chckbxTerms.isSelected()) {
						JOptionPane.showMessageDialog(null, "Para continuar debe aceptar nuestros T�rminos y Condiciones", "T�rminos no aceptados", 0, null);
					} else if (!enviar) {
						JOptionPane.showMessageDialog(null, "Direcci�n de correo electr�nico inv�lida", "E-Mail no v�lido", 0, null);
						txtMail.setText("");
					} else if (email != 0) {
						JOptionPane.showMessageDialog(null, "El E-Mail introducido ya existe, por favor introduzca otro", "E-Mail ya existente", 0, null);
						txtMail.setText("");
					} else if (user != 0) {
						JOptionPane.showMessageDialog(null, "El usuario introducido ya existe, por favor introduzca otro", "Usuario ya existente", 0, null);
						txtUser.setText("");
					}else {
						SendMail.enviar(mail, nick, pass);
						Connection conexion=DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			        	Statement comando=conexion.createStatement();
						comando.executeUpdate("INSERT INTO usuarios(`nick`,`pass`,`email`,`fk_img`) VALUES ('" + nick + "','" + pass + "','" + mail + "'," + img + ");");
				        LogIn logIn = new LogIn();
						logIn.setVisible(true);
				        dispose();
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnRegister.setBackground(Color.WHITE);
		btnRegister.setBounds(124, 271, 317, 31);
		panel_2.add(btnRegister);
		
		txtPass = new JPasswordField();
		txtPass.setBounds(265, 150, 176, 26);
		panel_2.add(txtPass);
		
		chckbxTerms = new JCheckBox("He le\u00EDdo y acepto los");
		chckbxTerms.setEnabled(false);
		chckbxTerms.setForeground(Color.WHITE);
		chckbxTerms.setBackground(new Color(0, 51, 102));
		chckbxTerms.setBounds(124, 228, 145, 23);
		panel_2.add(chckbxTerms);
		
		JLabel lblNewLabel = new JLabel("Terminos y Condiciones");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TerminosCondiciones terminosCondiciones = new TerminosCondiciones();
				terminosCondiciones.setVisible(true);
				lblNewLabel.setForeground(new Color(188, 28, 252));
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		});
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(275, 228, 166, 23);
		panel_2.add(lblNewLabel);
		
		JLabel lblProfile = new JLabel("");
		lblProfile.setIcon(new ImageIcon("assets/profile/"+img+".png"));
		lblProfile.setBounds(617, 75, 256, 256);
		panel_2.add(lblProfile);
		
		JButton btnPrev = new JButton("<");
		btnPrev.setFocusable(false);
		btnPrev.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (img == 1) {
					img = 21;
					lblProfile.setIcon(new ImageIcon("assets/profile/"+img+".png"));
				} else {
					img--;
					lblProfile.setIcon(new ImageIcon("assets/profile/"+img+".png"));
				}
			}
		});
		btnPrev.setFont(new Font("Tahoma", Font.PLAIN, 25));
		btnPrev.setBounds(684, 342, 55, 45);
		panel_2.add(btnPrev);
		
		JButton btnNext = new JButton(">");
		btnNext.setFocusable(false);
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (img == 21) {
					img = 1;
					lblProfile.setIcon(new ImageIcon("assets/profile/"+img+".png"));
				} else {
					img++;
					lblProfile.setIcon(new ImageIcon("assets/profile/"+img+".png"));
				}
			}
		});
		btnNext.setFont(new Font("Tahoma", Font.PLAIN, 25));
		btnNext.setBounds(749, 342, 55, 45);
		panel_2.add(btnNext);
		
		JLabel lblRepass = new JLabel("Re-Pass");
		lblRepass.setForeground(Color.WHITE);
		lblRepass.setFont(new Font("Ravie", Font.PLAIN, 20));
		lblRepass.setBounds(124, 190, 131, 27);
		panel_2.add(lblRepass);
		
		txtPass2 = new JPasswordField();
		txtPass2.setBounds(265, 189, 176, 26);
		panel_2.add(txtPass2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3.setBackground(new Color(0, 51, 102));
		panel_3.setBounds(100, 51, 360, 280);
		panel_2.add(panel_3);
		panel_3.setLayout(null);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(Color.BLACK);
		panel_5.setBounds(175, 196, 136, 2);
		panel_3.add(panel_5);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new LineBorder(new Color(0, 0, 0), 4));
		panel_4.setBackground(new Color(255, 255, 255));
		panel_4.setBounds(609, 51, 266, 280);
		panel_2.add(panel_4);
		
		JLabel lblAtras = new JLabel("");
		lblAtras.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				Principal principal = new Principal();
				principal.setVisible(true);
			}
		});
		lblAtras.setBounds(10, 360, 50, 50);
		lblAtras.setIcon(new ImageIcon("assets/volver.png"));
		panel_2.add(lblAtras);
		
	}
}
