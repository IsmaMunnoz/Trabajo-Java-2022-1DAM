import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javazoom.jl.decoder.JavaLayerException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Canvas;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JTextPane;

public class Principal extends JFrame {

	private JPanel contentPane;
	private static Principal frame;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Principal();
					frame.setVisible(true);
				
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Principal() {
		setTitle("Pregunta2");
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin-dam1b\\Desktop\\Trabajo\\FinalDeCurso\\assets\\logo.png"));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1216, 715);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(239, 184, 16));
		panel.setBounds(0, 0, 1200, 128);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(239, 184, 16));
		panel_1.setBounds(189, 11, 822, 110);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("2");
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBounds(741, -11, 79, 132);
		panel_1.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Curlz MT", Font.BOLD, 99));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblNewLabel_1 = new JLabel("PREGUNTA");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setBounds(36, 11, 695, 132);
		panel_1.add(lblNewLabel_1);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Ravie", Font.PLAIN, 99));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 51, 102));
		panel_2.setBounds(0, 122, 1200, 554);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JButton btnLogIn = new JButton("LOGIN");
		btnLogIn.setFocusable(false);
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LogIn logIn = new LogIn();
				logIn.setVisible(true);
				dispose();
			}
		});
		btnLogIn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnLogIn.setBackground(new Color(239, 184, 16)); 
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnLogIn.setBackground(new Color(255, 255, 180));
			}
		});
		btnLogIn.setForeground(new Color(0, 0, 0));
		btnLogIn.setBackground(new Color(255, 255, 180));
		btnLogIn.setFont(new Font("Ravie", Font.PLAIN, 50));
		btnLogIn.setBounds(350, 60, 500, 198);
		panel_2.add(btnLogIn);
		
		JButton btnRegister = new JButton("REGISTER");
		btnRegister.setFocusable(false);
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Registro registro = new Registro();
				registro.setVisible(true);
				dispose();
			}
		});
		btnRegister.setForeground(new Color(0, 0, 0));
		btnRegister.setBackground(new Color(255, 255, 180));
		btnRegister.setFont(new Font("Ravie", Font.PLAIN, 45));
		btnRegister.setBounds(350, 283, 500, 198);
		panel_2.add(btnRegister);
		btnRegister.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnRegister.setBackground(new Color(239, 184, 16));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnRegister.setBackground(new Color(255, 255, 180));
			}
		});
		
		JLabel lblInter = new JLabel("");
		lblInter.setHorizontalAlignment(SwingConstants.CENTER);
		lblInter.setBounds(893, 38, 297, 443);
		panel_2.add(lblInter);
		lblInter.setIcon(new ImageIcon("assets/abrir.gif"));
		
		JLabel lblInter2 = new JLabel("");
		lblInter2.setHorizontalAlignment(SwingConstants.CENTER);
		lblInter2.setBounds(10, 38, 297, 443);
		panel_2.add(lblInter2);
		lblInter2.setIcon(new ImageIcon("assets/cerrar.gif"));
		
		JLabel lblInter_1 = new JLabel("");
		lblInter_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblInter_1.setBounds(893, 60, 297, 443);
		panel_2.add(lblInter_1);
		
		JLabel lblInter2_1 = new JLabel("");
		lblInter2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblInter2_1.setBounds(10, 60, 297, 443);
		panel_2.add(lblInter2_1);
		
	}
}
