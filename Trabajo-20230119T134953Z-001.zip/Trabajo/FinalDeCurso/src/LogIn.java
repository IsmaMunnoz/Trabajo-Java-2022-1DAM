import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javazoom.jl.decoder.JavaLayerException;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.border.LineBorder;

public class LogIn extends JFrame {

	private JPanel contentPane;
	static String user;
	static String pass;
	static boolean var;
	private JTextField txtUser;
	private JPasswordField txtPass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LogIn frame = new LogIn();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LogIn() {
		setTitle("Pregunta2");
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin-dam1b\\Desktop\\Trabajo\\FinalDeCurso\\assets\\logo.png"));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 986, 582);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(239, 184, 16));
		panel.setBounds(0, 0, 970, 128);
		contentPane.add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(239, 184, 16));
		panel_1.setBounds(98, 11, 822, 110);
		panel.add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("LOG IN");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setFont(new Font("Ravie", Font.PLAIN, 99));
		lblNewLabel_1.setBounds(53, 0, 695, 132);
		panel_1.add(lblNewLabel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 51, 102));
		panel_2.setBounds(0, 127, 970, 416);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNick = new JLabel("Nick");
		lblNick.setForeground(new Color(255, 255, 255));
		lblNick.setFont(new Font("Ravie", Font.PLAIN, 20));
		lblNick.setBounds(343, 148, 59, 27);
		panel_2.add(lblNick);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setForeground(new Color(255, 255, 255));
		lblPassword.setFont(new Font("Ravie", Font.PLAIN, 20));
		lblPassword.setBounds(343, 221, 131, 27);
		panel_2.add(lblPassword);
		
		txtPass = new JPasswordField();
		txtPass.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtPass.setBounds(485, 216, 131, 27);
		panel_2.add(txtPass);
		
		JButton btnIniciarSesion = new JButton("Iniciar Sesi\u00F3n");
		btnIniciarSesion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				user = txtUser.getText();
                pass = String.valueOf(txtPass.getPassword());
                try {
                    Connection conexion;
                    conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
                    Statement comando=conexion.createStatement();
                    ResultSet registro = comando.executeQuery("select nick,pass from usuarios where nick like '"+user+"' and pass like '"+pass+"';");
                    if (registro.next()==true) {
                    	ResultSet ban = comando.executeQuery("select baneado from usuarios where nick like '"+user+"' and pass like '"+pass+"';");
                    	ban.next();
                    	Boolean banned = ban.getBoolean(1);
                    	if (banned) {
							JOptionPane.showMessageDialog(null, "Lo sentimos, este usuario ha sido baneado", "Usuario baneado", 0, null);
						} else {
							ResultSet admin = comando.executeQuery("select admin from usuarios where nick like '"+user+"' and pass like '"+pass+"';");
	                        admin.next();
	                        var = admin.getBoolean(1);
	                        if (var) {
	                            dispose();
	                            InicioAdmin inicioAdmin = new InicioAdmin();
	                            inicioAdmin.setVisible(true);
	                        } else {
	                            dispose();
	                            InicioUser inicioUser = new InicioUser();
	                            inicioUser.setVisible(true);
	                        }
						}
                    } else {
                        JOptionPane.showMessageDialog(null, "Usuario y/o Contrase�a incorrecta", "Error al Iniciar Sesi�n", 0, null);
                        txtUser.setText("");
                        txtPass.setText("");
                    }
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
			}
		});
		btnIniciarSesion.setBounds(343, 289, 273, 38);
		panel_2.add(btnIniciarSesion);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		panel_3.setBackground(new Color(0, 51, 102));
		panel_3.setBounds(281, 49, 399, 314);
		panel_2.add(panel_3);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 11, 379, 55);
		panel_3.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon("assets/titulo.png"));
		
		txtUser = new JTextField();
		txtUser.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtUser.setBounds(203, 94, 131, 27);
		panel_3.add(txtUser);
		txtUser.setColumns(10);
		
		JLabel lblAbrir = new JLabel("");
		lblAbrir.setBounds(10, 49, 236, 314);
		panel_2.add(lblAbrir);
		lblAbrir.setIcon(new ImageIcon("assets/inter2.gif"));
		
		JLabel lblCerrar = new JLabel("");
		lblCerrar.setBounds(724, 49, 236, 314);
		panel_2.add(lblCerrar);
		lblCerrar.setIcon(new ImageIcon("assets/inter.gif"));

		JLabel lblAtras = new JLabel("");
		lblAtras.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				Principal principal = new Principal();
				principal.setVisible(true);
			}
		});
		lblAtras.setBounds(10, 360, 50, 50);
		lblAtras.setIcon(new ImageIcon("assets/volver.png"));
		panel_2.add(lblAtras);
		
	}
}
