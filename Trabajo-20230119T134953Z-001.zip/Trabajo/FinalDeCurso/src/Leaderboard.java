import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import javazoom.jl.decoder.JavaLayerException;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Leaderboard extends JFrame {

	private JPanel contentPane;
	private static Leaderboard frame;
	private JLabel lblMusica;
	private JLabel lblPunt1, lblPunt2, lblPunt3, lblPunt4, lblPunt5;
	private JLabel lblNick1, lblNick2, lblNick3, lblNick4, lblNick5;
	private String pos;
	static InicioUser i = new InicioUser();
	static int volver;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Leaderboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Leaderboard() {
		setTitle("Pregunta2");
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin-dam1b\\Desktop\\Trabajo\\FinalDeCurso\\assets\\logo.png"));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1216, 715);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(239, 184, 16));
		panel.setBounds(0, 0, 1200, 128);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(239, 184, 16));
		panel_1.setBounds(78, 11, 1037, 110);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("RESULTADO");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setBounds(10, 11, 1014, 132);
		panel_1.add(lblNewLabel_1);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Ravie", Font.PLAIN, 99));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 51, 102));
		panel_2.setBounds(0, 122, 1200, 554);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(0, 75, 150));
		panel_3.setBounds(300, 77, 600, 383);
		panel_2.add(panel_3);
		panel_3.setLayout(null);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(10, 10, 580, 50);
		panel_3.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("1");
		lblNewLabel.setFont(new Font("Bell MT", Font.BOLD, 50));
		lblNewLabel.setForeground(new Color(239, 184, 16));
		lblNewLabel.setBackground(new Color(102, 51, 0));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 0, 64, 50);
		panel_4.add(lblNewLabel);
		
		lblNick1 = new JLabel("");
		lblNick1.setFont(new Font("Ravie", Font.BOLD, 20));
		lblNick1.setForeground(new Color(239, 184, 16));
		lblNick1.setBounds(112, 0, 340, 50);
		panel_4.add(lblNick1);
		
		lblPunt1 = new JLabel();
		lblPunt1.setText("0");
		lblPunt1.setHorizontalAlignment(SwingConstants.CENTER);
		lblPunt1.setForeground(new Color(239, 184, 16));
		lblPunt1.setFont(new Font("Bell MT", Font.BOLD, 50));
		lblPunt1.setBounds(506, 0, 64, 50);
		panel_4.add(lblPunt1);
		
		try {
			Connection conexion;
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando=conexion.createStatement();
			ResultSet resultado = comando.executeQuery("select puntuacion from leaderboard order by puntuacion desc limit 0,1;");
			resultado.next();
			String puntu = resultado.getString(1);
			lblPunt1.setText(puntu);
			resultado = comando.executeQuery("select nick from usuarios join leaderboard on usuarios.id = leaderboard.fk_jugador order by leaderboard.puntuacion desc limit 0,1;");
			resultado.next();
			puntu = resultado.getString(1);
			lblNick1.setText(puntu);
		} catch (Exception e) {
			//e.printStackTrace();
		}
		
		JPanel panel_4_1 = new JPanel();
		panel_4_1.setBounds(10, 82, 580, 50);
		panel_3.add(panel_4_1);
		panel_4_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("2");
		lblNewLabel_2.setFont(new Font("Bell MT", Font.BOLD, 50));
		lblNewLabel_2.setForeground(new Color(138, 149, 151));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(0, 0, 64, 50);
		panel_4_1.add(lblNewLabel_2);
		
		lblNick2 = new JLabel("");
		lblNick2.setFont(new Font("Ravie", Font.BOLD, 20));
		lblNick2.setForeground(new Color(138, 149, 151));
		lblNick2.setBounds(112, 0, 340, 50);
		panel_4_1.add(lblNick2);
		
		lblPunt2 = new JLabel();
		lblPunt2.setText("0");
		lblPunt2.setHorizontalAlignment(SwingConstants.CENTER);
		lblPunt2.setForeground(new Color(138, 149, 151));
		lblPunt2.setFont(new Font("Bell MT", Font.BOLD, 50));
		lblPunt2.setBounds(506, 0, 64, 50);
		panel_4_1.add(lblPunt2);
		
		try {
			Connection conexion;
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando=conexion.createStatement();
			ResultSet resultado = comando.executeQuery("select puntuacion from leaderboard order by puntuacion desc limit 1,1;");
			resultado.next();
			String puntu = resultado.getString(1);
			lblPunt2.setText(puntu);
			resultado = comando.executeQuery("select nick from usuarios join leaderboard on usuarios.id = leaderboard.fk_jugador order by leaderboard.puntuacion desc limit 1,1;");
			resultado.next();
			puntu = resultado.getString(1);
			lblNick2.setText(puntu);
		} catch (Exception e) {
			//e.printStackTrace();
		}
		
		JPanel panel_4_2 = new JPanel();
		panel_4_2.setBounds(10, 154, 580, 50);
		panel_3.add(panel_4_2);
		panel_4_2.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("3");
		lblNewLabel_3.setFont(new Font("Bell MT", Font.BOLD, 50));
		lblNewLabel_3.setForeground(new Color(205, 127, 50));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(0, 0, 64, 50);
		panel_4_2.add(lblNewLabel_3);
		
		lblNick3 = new JLabel("");
		lblNick3.setFont(new Font("Ravie", Font.BOLD, 20));
		lblNick3.setForeground(new Color(205, 127, 50));
		lblNick3.setBounds(112, 0, 340, 50);
		panel_4_2.add(lblNick3);
		
		lblPunt3 = new JLabel();
		lblPunt3.setText("0");
		lblPunt3.setHorizontalAlignment(SwingConstants.CENTER);
		lblPunt3.setForeground(new Color(205, 127, 50));
		lblPunt3.setFont(new Font("Bell MT", Font.BOLD, 50));
		lblPunt3.setBounds(506, 0, 64, 50);
		panel_4_2.add(lblPunt3);
		
		try {
			Connection conexion;
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando=conexion.createStatement();
			ResultSet resultado = comando.executeQuery("select puntuacion from leaderboard order by puntuacion desc limit 2,1;");
			resultado.next();
			String puntu = resultado.getString(1);
			lblPunt3.setText(puntu);
			resultado = comando.executeQuery("select nick from usuarios join leaderboard on usuarios.id = leaderboard.fk_jugador order by leaderboard.puntuacion desc limit 2,1;");
			resultado.next();
			puntu = resultado.getString(1);
			lblNick3.setText(puntu);
		} catch (Exception e) {
			//e.printStackTrace();
		}
		
		JPanel panel_4_3 = new JPanel();
		panel_4_3.setBounds(10, 236, 580, 50);
		panel_3.add(panel_4_3);
		panel_4_3.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("4");
		lblNewLabel_4.setFont(new Font("Bell MT", Font.BOLD, 50));
		lblNewLabel_4.setForeground(new Color(0, 0, 0));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(0, 0, 64, 50);
		panel_4_3.add(lblNewLabel_4);
		
		lblNick4 = new JLabel("");
		lblNick4.setFont(new Font("Ravie", Font.BOLD, 20));
		lblNick4.setForeground(new Color(0, 0, 0));
		lblNick4.setBounds(112, 0, 340, 50);
		panel_4_3.add(lblNick4);
		
		lblPunt4 = new JLabel();
		lblPunt4.setText("0");
		lblPunt4.setHorizontalAlignment(SwingConstants.CENTER);
		lblPunt4.setForeground(Color.BLACK);
		lblPunt4.setFont(new Font("Bell MT", Font.BOLD, 50));
		lblPunt4.setBounds(506, 0, 64, 50);
		panel_4_3.add(lblPunt4);
		
		try {
			Connection conexion;
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando=conexion.createStatement();
			ResultSet resultado = comando.executeQuery("select puntuacion from leaderboard order by puntuacion desc limit 3,1;");
			resultado.next();
			String puntu = resultado.getString(1);
			lblPunt4.setText(puntu);
			resultado = comando.executeQuery("select nick from usuarios join leaderboard on usuarios.id = leaderboard.fk_jugador order by leaderboard.puntuacion desc limit 3,1;");
			resultado.next();
			puntu = resultado.getString(1);
			lblNick4.setText(puntu);
		} catch (Exception e) {
			//e.printStackTrace();
		}
		
		JPanel panel_4_4 = new JPanel();
		panel_4_4.setBounds(10, 318, 580, 50);
		panel_3.add(panel_4_4);
		panel_4_4.setLayout(null);
		
		JLabel lblNewLabel_5 = new JLabel("5");
		lblNewLabel_5.setFont(new Font("Bell MT", Font.BOLD, 50));
		lblNewLabel_5.setForeground(new Color(0, 0, 0));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(0, 0, 64, 50);
		panel_4_4.add(lblNewLabel_5);
		
		lblNick5 = new JLabel("");
		lblNick5.setFont(new Font("Ravie", Font.BOLD, 20));
		lblNick5.setForeground(new Color(0, 0, 0));
		lblNick5.setBounds(112, 0, 340, 50);
		panel_4_4.add(lblNick5);
		
		lblPunt5 = new JLabel();
		lblPunt5.setText("0");
		lblPunt5.setHorizontalAlignment(SwingConstants.CENTER);
		lblPunt5.setForeground(Color.BLACK);
		lblPunt5.setFont(new Font("Bell MT", Font.BOLD, 50));
		lblPunt5.setBounds(506, 0, 64, 50);
		panel_4_4.add(lblPunt5);
		
		try {
			Connection conexion;
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando=conexion.createStatement();
			ResultSet resultado = comando.executeQuery("select puntuacion from leaderboard order by puntuacion desc limit 4,1;");
			resultado.next();
			String puntu = resultado.getString(1);
			lblPunt5.setText(puntu);
			resultado = comando.executeQuery("select nick from usuarios join leaderboard on usuarios.id = leaderboard.fk_jugador order by leaderboard.puntuacion desc limit 4,1;");
			resultado.next();
			puntu = resultado.getString(1);
			lblNick5.setText(puntu);
		} catch (Exception e) {
			//e.printStackTrace();
		}
		
		try {
			Connection conexion;
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando=conexion.createStatement();
			ResultSet resultado = comando.executeQuery("select leaderboard.puntuacion from leaderboard join usuarios on usuarios.id = leaderboard.fk_jugador where usuarios.nick like '"+ LogIn.user +"';");
			resultado.next();
			int pos = resultado.getRow();
		} catch (Exception e) {
			//e.printStackTrace();
		}
		
		JLabel lblOro = new JLabel("");
		lblOro.setHorizontalAlignment(SwingConstants.CENTER);
		lblOro.setIcon(new ImageIcon("assets/oro.gif"));
		lblOro.setBounds(255, 87, 50, 60);
		panel_2.add(lblOro);
		
		JLabel lblPlata = new JLabel("");
		lblPlata.setHorizontalAlignment(SwingConstants.CENTER);
		lblPlata.setIcon(new ImageIcon("assets/plata.gif"));
		lblPlata.setBounds(255, 158, 50, 60);
		panel_2.add(lblPlata);
		
		JLabel lblBronce = new JLabel("");
		lblBronce.setHorizontalAlignment(SwingConstants.CENTER);
		lblBronce.setIcon(new ImageIcon("assets/bronce.gif"));
		lblBronce.setBounds(255, 229, 50, 60);
		panel_2.add(lblBronce);
		
		JLabel lblAtras = new JLabel("");
		lblAtras.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (volver == 1) {
					InicioAdmin inicioadmin = new InicioAdmin();
					inicioadmin.setVisible(true);
					dispose();
				} else if (volver == 0) {
					InicioUser iniciouser = new InicioUser();
					iniciouser.setVisible(true);
					dispose();
				}
			}
		});
		lblAtras.setBounds(10, 493, 50, 50);
		lblAtras.setIcon(new ImageIcon("assets/volver.png"));
		panel_2.add(lblAtras);
	}
}
