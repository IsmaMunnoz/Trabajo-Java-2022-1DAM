import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Canvas;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class AdminReiniciar extends JFrame {

    private JPanel contentPane;
    private static AdminReiniciar frame;
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    frame = new AdminReiniciar();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public AdminReiniciar() {
    	setTitle("Pregunta2");
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin-dam1b\\Desktop\\Trabajo\\FinalDeCurso\\assets\\logo.png"));
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 814, 425);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 0));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
       
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(Color.BLACK);
        panel_1.setBorder(new LineBorder(Color.GREEN, 2));
        panel_1.setBounds(10, 11, 778, 364);
        contentPane.add(panel_1);
        panel_1.setLayout(null);
       
        JButton btnReiniciarUser = new JButton("Reiniciar Usuarios");
        btnReiniciarUser.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
    			try {
            		Connection conexion;
        			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
        			Statement comando=conexion.createStatement();
					comando.executeUpdate("DELETE FROM `trivial`.`usuarios` where id != 1;");
					JOptionPane.showMessageDialog(null, "Usuarios Eliminado Correctamente", "Users Eliminado", 1, null);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
        	}
        });
        btnReiniciarUser.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnReiniciarUser.setBackground(Color.GREEN);
                btnReiniciarUser.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnReiniciarUser.setBackground(Color.BLACK);
                btnReiniciarUser.setForeground(Color.GREEN);
            }
        });
        btnReiniciarUser.setFont(new Font("Serif", Font.PLAIN, 20));
        btnReiniciarUser.setBackground(Color.BLACK);
        btnReiniciarUser.setFocusable(false);
        btnReiniciarUser.setForeground(Color.GREEN);
        btnReiniciarUser.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnReiniciarUser.setBounds(10, 11, 758, 46);
        panel_1.add(btnReiniciarUser);
       
        JButton btnReiniciarPreguntas = new JButton("Reiniciar Preguntas");
        btnReiniciarPreguntas.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
            		Connection conexion;
        			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
        			Statement comando=conexion.createStatement();
					comando.executeUpdate("DELETE FROM `trivial`.`preguntas_respuestas`;");
					JOptionPane.showMessageDialog(null, "Preguntas Eliminadas Correctamente", "Preguntas Eliminadas", 1, null);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
        	}
        });
        btnReiniciarPreguntas.setForeground(Color.GREEN);
        btnReiniciarPreguntas.setFont(new Font("Serif", Font.PLAIN, 20));
        btnReiniciarPreguntas.setFocusable(false);
        btnReiniciarPreguntas.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnReiniciarPreguntas.setBackground(Color.BLACK);
        btnReiniciarPreguntas.setBounds(10, 108, 758, 46);
        panel_1.add(btnReiniciarPreguntas);
        btnReiniciarPreguntas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            	btnReiniciarPreguntas.setBackground(Color.GREEN);
            	btnReiniciarPreguntas.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
            	btnReiniciarPreguntas.setBackground(Color.BLACK);
            	btnReiniciarPreguntas.setForeground(Color.GREEN);
            }
        });
       
        JButton btnSalir = new JButton("Volver");
        btnSalir.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		dispose();
        		Administrar administrar = new Administrar();
				administrar.setVisible(true);
        	}
        });
        btnSalir.setBounds(10, 302, 758, 46);
        panel_1.add(btnSalir);
        btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            	btnSalir.setBackground(Color.GREEN);
            	btnSalir.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
            	btnSalir.setBackground(Color.BLACK);
            	btnSalir.setForeground(Color.GREEN);
            }
        });
        btnSalir.setForeground(Color.GREEN);
        btnSalir.setFont(new Font("Serif", Font.PLAIN, 20));
        btnSalir.setFocusable(false);
        btnSalir.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnSalir.setBackground(Color.BLACK);
        
        JButton btnReiniciarLeaderboard = new JButton("Reiniciar Leaderboard");
        btnReiniciarLeaderboard.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
            		Connection conexion;
        			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
        			Statement comando=conexion.createStatement();
					comando.executeUpdate("DELETE FROM `trivial`.`leaderboard`;");
					JOptionPane.showMessageDialog(null, "Ranking Eliminado Correctamente", "Ranking Eliminado", 1, null);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
        	}
        });
        btnReiniciarLeaderboard.setForeground(Color.GREEN);
        btnReiniciarLeaderboard.setFont(new Font("Serif", Font.PLAIN, 20));
        btnReiniciarLeaderboard.setFocusable(false);
        btnReiniciarLeaderboard.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnReiniciarLeaderboard.setBackground(Color.BLACK);
        btnReiniciarLeaderboard.setBounds(10, 205, 758, 46);
        panel_1.add(btnReiniciarLeaderboard);
        btnReiniciarLeaderboard.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
            	btnReiniciarLeaderboard.setBackground(Color.GREEN);
            	btnReiniciarLeaderboard.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
            	btnReiniciarLeaderboard.setBackground(Color.BLACK);
            	btnReiniciarLeaderboard.setForeground(Color.GREEN);
            }
        });
    }

	protected void pintar() {
		try {
			Connection conexion;
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando=conexion.createStatement();
			//ResultSet resultado = comando.executeQuery("select img_perfil.img from img_perfil join usuarios on img_perfil.id = usuarios.fk_img where nick like '"+txtBuscar.getText()+"';");
			//resultado.next();
			//String dato = resultado.getString(1);
			//lblFoto.setIcon(new ImageIcon("assets/profile/"+dato));
			//resultado = comando.executeQuery("select nick from usuarios where nick like '"+txtBuscar.getText()+"';");
			//resultado.next();
			//dato = resultado.getString(1);
			//txtNick.setText(dato);
			//resultado = comando.executeQuery("select pass from usuarios where nick like '"+txtBuscar.getText()+"';");
			//resultado.next();
//			dato = resultado.getString(1);
//			txtPass.setText(dato);
//			resultado = comando.executeQuery("select email from usuarios where nick like '"+txtBuscar.getText()+"';");
//			resultado.next();
//			dato = resultado.getString(1);
//			txtMail.setText(dato);
//			resultado = comando.executeQuery("select admin from usuarios where nick like '"+txtBuscar.getText()+"';");
//			resultado.next();
//			Boolean estado = resultado.getBoolean(1);
//			if (estado) {
//				chckAdmin.setSelected(true);
//				txtPermisos.setText("Administrador");
//			} else {
//				chckAdmin.setSelected(false);
//				txtPermisos.setText("Usuario");
//			}
//			resultado = comando.executeQuery("select baneado from usuarios where nick like '"+txtBuscar.getText()+"';");
//			resultado.next();
//			estado = resultado.getBoolean(1);
//			if (!estado) {
//				chckBan.setSelected(false);
//				txtEstado.setText("Activo");
//			} else {
//				chckBan.setSelected(true);
//				txtEstado.setText("Baneado");
//			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
	}

	/*protected void banear() {
		if (chckBan.isSelected()) {
			Connection conexion;
			try {
				conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
				Statement comando=conexion.createStatement();
				comando.executeUpdate("UPDATE `usuarios` SET `baneado` = '1' WHERE `usuarios`.`nick` like'"+txtBuscar.getText()+"';");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			Connection conexion;
			try {
				conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
				Statement comando=conexion.createStatement();
				comando.executeUpdate("UPDATE `usuarios` SET `baneado` = '0' WHERE `usuarios`.`nick` like'"+txtBuscar.getText()+"';");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	protected void permisos() {
		if (chckAdmin.isSelected()) {
			chckAdmin.setSelected(false);
			txtPermisos.setText("Usuario");
			Connection conexion;
			try {
				conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
				Statement comando=conexion.createStatement();
				comando.executeUpdate("UPDATE `usuarios` SET `admin` = '1' WHERE `usuarios`.`nick` like'"+txtBuscar.getText()+"';");
				pintar();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			chckAdmin.setSelected(true);
			txtPermisos.setText("Administrador");
			Connection conexion;
			try {
				conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
				Statement comando=conexion.createStatement();
				comando.executeUpdate("UPDATE `usuarios` SET `admin` = '0' WHERE `usuarios`.`nick` like'"+txtBuscar.getText()+"';");
				pintar();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}*/
}