import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JProgressBar;
import javax.swing.Timer;
import java.awt.Color;

public class Splash extends JFrame {

    private JPanel contentPane;
    static int progress;
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Splash frame = new Splash();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Splash() {
    	setAlwaysOnTop(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 560);
        contentPane = new JPanel();
        this.setUndecorated(true);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        setLocationRelativeTo(null);
        contentPane.setLayout(null);
       
        JLabel lblTitulo = new JLabel("");
        lblTitulo.setIcon(new ImageIcon("assets/preguntados.jpeg"));
        lblTitulo.setBounds(0, 0, 1000, 560);
        contentPane.add(lblTitulo);
       
        JProgressBar progressBar = new JProgressBar();
        progressBar.setForeground(new Color(0, 255, 0));
        progressBar.setBounds(0, 540, 1000, 20);
        contentPane.add(progressBar);
       
        Timer timer = new Timer(150, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	progressBar.setStringPainted(true);   
            	progress += Math.random()*10;
                        if (progress >= 100) {
                          progress = 100;
                          ((Timer) e.getSource()).stop();
                        }
                        progressBar.setValue(progress);
                        if (progress==100) {
                        	Principal principal = new Principal();
							principal.setVisible(true);
                        	dispose();
                        }
                      }
            });
        timer.start();
           
       
}

}