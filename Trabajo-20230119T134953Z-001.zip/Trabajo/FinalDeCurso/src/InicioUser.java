import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javazoom.jl.decoder.JavaLayerException;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Canvas;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.border.LineBorder;

public class InicioUser extends JFrame {

	private JPanel contentPane;
	private static InicioUser frame;
	static JLabel lblUser;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new InicioUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InicioUser() {
		setTitle("Pregunta2");
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin-dam1b\\Desktop\\Trabajo\\FinalDeCurso\\assets\\logo.png"));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1216, 715);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(239, 184, 16));
		panel.setBounds(0, 0, 1200, 128);
		contentPane.add(panel);
		panel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(239, 184, 16));
		panel_1.setBounds(189, 11, 822, 110);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel = new JLabel("2");
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBounds(741, -11, 79, 132);
		panel_1.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Curlz MT", Font.BOLD, 99));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);

		JLabel lblNewLabel_1 = new JLabel("PREGUNTA");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setBounds(36, 11, 695, 132);
		panel_1.add(lblNewLabel_1);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Ravie", Font.PLAIN, 99));
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		panel_3.setBounds(36, 27, 75, 76);
		panel.add(panel_3);
		
		JLabel lblProfile = new JLabel("");
		panel_3.add(lblProfile);
		try {
			Connection conexion;
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando=conexion.createStatement();
			ResultSet resultado = comando.executeQuery("select img_perfil.img from img_perfil join usuarios on img_perfil.id = usuarios.fk_img where nick like '"+LogIn.user+"';");
			resultado.next();
			String img = resultado.getString(1);
			lblProfile.setIcon(new ImageIcon("assets/user/"+img));
		} catch (SQLException e1) {
			lblProfile.setIcon(new ImageIcon("assets/user/1.png"));
			e1.printStackTrace();
		}

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 51, 102));
		panel_2.setBounds(0, 122, 1200, 554);
		contentPane.add(panel_2);
		panel_2.setLayout(null);

		JButton btnJugar = new JButton("JUGAR");
		btnJugar.setFocusable(false);
		btnJugar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Connection conexion;
	    			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
	    			Statement comando=conexion.createStatement();
	    			comando.executeUpdate("INSERT INTO `partidas`(`player`) VALUES ('" + LogIn.user + "');");
	    			Jugar jugar = new Jugar();
					jugar.setVisible(true);
					dispose();
				} catch (Exception e2) {
					// TODO: handle exception
					e2.printStackTrace();
				}
			}
		});
		btnJugar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnJugar.setBackground(new Color(239, 184, 16));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				btnJugar.setBackground(new Color(255, 255, 180));
			}
		});
		btnJugar.setForeground(new Color(0, 0, 0));
		btnJugar.setBackground(new Color(255, 255, 180));
		btnJugar.setFont(new Font("Ravie", Font.PLAIN, 50));
		btnJugar.setBounds(350, 66, 500, 131);
		panel_2.add(btnJugar);

		JButton btnRank = new JButton("LEADERBOARD");
		btnRank.setFocusable(false);
		btnRank.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Leaderboard.volver = 0;
				Leaderboard leaderboard = new Leaderboard();
				leaderboard.setVisible(true);
				dispose();
			}
		});
		btnRank.setForeground(new Color(0, 0, 0));
		btnRank.setBackground(new Color(255, 255, 180));
		btnRank.setFont(new Font("Ravie", Font.PLAIN, 45));
		btnRank.setBounds(350, 208, 500, 131);
		panel_2.add(btnRank);
		btnRank.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnRank.setBackground(new Color(239, 184, 16));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				btnRank.setBackground(new Color(255, 255, 180));
			}
		});

		JButton btnSalir = new JButton("SALIR");
		btnSalir.setFocusable(false);
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JLabel etiqueta = new JLabel("Gracias por jugar");
			    etiqueta.setFont(new Font("Ravie", Font.PLAIN, 15));
			    etiqueta.setHorizontalAlignment(SwingConstants.CENTER);
			    JOptionPane.showMessageDialog(null, etiqueta, "Saliendo", JOptionPane.PLAIN_MESSAGE);
				dispose();
			}
		});
		btnSalir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnSalir.setBackground(new Color(239, 184, 16));
			}

			@Override
			public void mouseExited(MouseEvent e) {
				btnSalir.setBackground(new Color(255, 255, 180));
			}
		});
		btnSalir.setForeground(new Color(0, 0, 0));
		btnSalir.setBackground(new Color(255, 255, 180));
		btnSalir.setFont(new Font("Ravie", Font.PLAIN, 50));
		btnSalir.setBounds(350, 350, 500, 131);
		panel_2.add(btnSalir);

		JLabel lblInter = new JLabel("");
		lblInter.setHorizontalAlignment(SwingConstants.CENTER);
		lblInter.setBounds(893, 38, 297, 443);
		panel_2.add(lblInter);
		lblInter.setIcon(new ImageIcon("assets/abrir.gif"));

		JLabel lblInter2 = new JLabel("");
		lblInter2.setHorizontalAlignment(SwingConstants.CENTER);
		lblInter2.setBounds(10, 38, 297, 443);
		panel_2.add(lblInter2);
		lblInter2.setIcon(new ImageIcon("assets/cerrar.gif"));
		
		JLabel lblNewLabel_2 = new JLabel("User: ");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setBounds(10, 529, 46, 14);
		panel_2.add(lblNewLabel_2);
		
		lblUser = new JLabel("");
		lblUser.setText(LogIn.user);
		lblUser.setForeground(Color.WHITE);
		lblUser.setBounds(47, 530, 145, 14);
		panel_2.add(lblUser);

	}
}
