import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Canvas;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class AdminUser extends JFrame {

    private JPanel contentPane;
    private static AdminUser frame;
    private JTextField txtBuscar;
    private JLabel lblFoto;
    private JCheckBox chckAdmin;
    private JCheckBox chckBan;
    private JTextField txtNick;
    private JTextField txtPass;
    private JTextField txtMail;
    private JTextField txtPermisos;
    private JTextField txtEstado;
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    frame = new AdminUser();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public AdminUser() {
    	setTitle("Pregunta2");
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin-dam1b\\Desktop\\Trabajo\\FinalDeCurso\\assets\\logo.png"));
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 814, 465);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 0));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
       
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(Color.GREEN, 2));
        panel.setBackground(Color.BLACK);
        panel.setBounds(10, 11, 778, 60);
        contentPane.add(panel);
        panel.setLayout(null);
       
        JLabel lblNewLabel = new JLabel("Usuario:");
        lblNewLabel.setBounds(10, 16, 68, 27);
        panel.add(lblNewLabel);
        lblNewLabel.setFont(new Font("Serif", Font.PLAIN, 20));
        lblNewLabel.setForeground(Color.GREEN);
       
        txtBuscar = new JTextField();
        txtBuscar.setBackground(Color.BLACK);
        txtBuscar.setForeground(Color.GREEN);
        txtBuscar.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        txtBuscar.setFont(new Font("Serif", Font.PLAIN, 20));
        txtBuscar.setBounds(83, 11, 198, 38);
        panel.add(txtBuscar);
        txtBuscar.setColumns(10);
       
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		pintar();
        	}
        });
        btnBuscar.setBackground(Color.BLACK);
        btnBuscar.setFocusable(false);
        btnBuscar.setForeground(Color.GREEN);
        btnBuscar.setBounds(280, 11, 89, 38);
        btnBuscar.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnBuscar.setFont(new Font("Serif", Font.PLAIN, 20));
        panel.add(btnBuscar);
        btnBuscar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnBuscar.setBackground(Color.GREEN);
                btnBuscar.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnBuscar.setBackground(Color.BLACK);
                btnBuscar.setForeground(Color.GREEN);
            }
        });
       
        JLabel lblNewLabel_1 = new JLabel("Administrador:");
        lblNewLabel_1.setForeground(Color.GREEN);
        lblNewLabel_1.setFont(new Font("Serif", Font.PLAIN, 20));
        lblNewLabel_1.setBounds(475, 16, 121, 27);
        panel.add(lblNewLabel_1);
       
        chckAdmin = new JCheckBox("");
        chckAdmin.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if (chckAdmin.isSelected()) {
        			txtPermisos.setText("Administrador");
        		} else {
        			txtPermisos.setText("Usuario");
        		}
        	}
        });
        chckAdmin.setBackground(Color.BLACK);
        chckAdmin.setBorder(new LineBorder(Color.GREEN, 5));
        chckAdmin.setBounds(598, 21, 21, 21);
        panel.add(chckAdmin);
       
        JLabel lblNewLabel_2 = new JLabel("Banear:");
        lblNewLabel_2.setForeground(Color.GREEN);
        lblNewLabel_2.setFont(new Font("Serif", Font.PLAIN, 20));
        lblNewLabel_2.setBounds(643, 16, 62, 27);
        panel.add(lblNewLabel_2);
       
        chckBan = new JCheckBox("");
        chckBan.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if (chckBan.isSelected()) {
        			txtEstado.setText("Baneado");
        		} else {
        			txtEstado.setText("Activo");
        		}
        	}
        });
        chckBan.setBackground(Color.BLACK);
        chckBan.setBounds(711, 21, 21, 21);
        panel.add(chckBan);
       
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(Color.BLACK);
        panel_1.setBorder(new LineBorder(Color.GREEN, 2));
        panel_1.setBounds(10, 82, 778, 334);
        contentPane.add(panel_1);
        panel_1.setLayout(null);
       
        lblFoto = new JLabel("");
        lblFoto.setBounds(10, 37, 256, 256);
        lblFoto.setBorder(new LineBorder(Color.GREEN, 2));
        lblFoto.setIcon(new ImageIcon(""));
        panel_1.add(lblFoto);
       
        JLabel lblNewLabel_4 = new JLabel("Nombre:");
        lblNewLabel_4.setForeground(Color.GREEN);
        lblNewLabel_4.setFont(new Font("Serif", Font.PLAIN, 20));
        lblNewLabel_4.setBounds(295, 37, 70, 27);
        panel_1.add(lblNewLabel_4);
       
        JLabel lblNewLabel_4_1 = new JLabel("Contrase\u00F1a:");
        lblNewLabel_4_1.setForeground(Color.GREEN);
        lblNewLabel_4_1.setFont(new Font("Serif", Font.PLAIN, 20));
        lblNewLabel_4_1.setBounds(295, 79, 94, 27);
        panel_1.add(lblNewLabel_4_1);
       
        JLabel lblNewLabel_4_1_1 = new JLabel("Email:");
        lblNewLabel_4_1_1.setForeground(Color.GREEN);
        lblNewLabel_4_1_1.setFont(new Font("Serif", Font.PLAIN, 20));
        lblNewLabel_4_1_1.setBounds(295, 121, 53, 27);
        panel_1.add(lblNewLabel_4_1_1);
       
        JLabel lblNewLabel_5 = new JLabel("Permisos:");
        lblNewLabel_5.setForeground(Color.GREEN);
        lblNewLabel_5.setFont(new Font("Serif", Font.PLAIN, 20));
        lblNewLabel_5.setBounds(295, 163, 79, 27);
        panel_1.add(lblNewLabel_5);
       
        JLabel lblNewLabel_5_1 = new JLabel("Estado:");
        lblNewLabel_5_1.setForeground(Color.GREEN);
        lblNewLabel_5_1.setFont(new Font("Serif", Font.PLAIN, 20));
        lblNewLabel_5_1.setBounds(295, 205, 60, 27);
        panel_1.add(lblNewLabel_5_1);
       
        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
    			try {
            		Connection conexion;
        			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
        			Statement comando=conexion.createStatement();
        			ResultSet iduser = comando.executeQuery("select id from usuarios where nick like '" + txtBuscar.getText() + "';");
        			iduser.next();
        			int id = iduser.getInt(1);
        			comando.executeUpdate("DELETE FROM `trivial`.`leaderboard` WHERE fk_jugador = "+ id +";");
        			comando.executeUpdate("DELETE FROM `trivial`.`partidas` WHERE player like '"+ txtBuscar.getText() +"';");
        			comando.executeUpdate("DELETE FROM `trivial`.`usuarios` WHERE nick like '"+ txtBuscar.getText() +"';");
					JOptionPane.showMessageDialog(null, "Usuario Eliminado Correctamente", "User Eliminado", 1, null);
					txtBuscar.setText("");
					txtNick.setText("");
					txtPass.setText("");
					txtMail.setText("");
					txtPermisos.setText("");
					txtEstado.setText("");
					lblFoto.setIcon(null);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
        	}
        });
        btnEliminar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnEliminar.setBackground(Color.GREEN);
                btnEliminar.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnEliminar.setBackground(Color.BLACK);
                btnEliminar.setForeground(Color.GREEN);
            }
        });
        btnEliminar.setFont(new Font("Serif", Font.PLAIN, 20));
        btnEliminar.setBackground(Color.BLACK);
        btnEliminar.setFocusable(false);
        btnEliminar.setForeground(Color.GREEN);
        btnEliminar.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnEliminar.setBounds(295, 247, 180, 46);
        panel_1.add(btnEliminar);
       
        txtNick = new JTextField("");
        txtNick.setBackground(Color.DARK_GRAY);
        txtNick.setBorder(null);
        txtNick.setForeground(Color.GREEN);
        txtNick.setFont(new Font("Serif", Font.PLAIN, 20));
        txtNick.setBounds(399, 37, 369, 27);
        panel_1.add(txtNick);
       
        txtPass = new JTextField("");
        txtPass.setBackground(Color.DARK_GRAY);
        txtPass.setBorder(null);
        txtPass.setForeground(Color.GREEN);
        txtPass.setFont(new Font("Serif", Font.PLAIN, 20));
        txtPass.setBounds(399, 79, 369, 27);
        panel_1.add(txtPass);
       
        txtMail = new JTextField("");
        txtMail.setBorder(null);
        txtMail.setBackground(Color.DARK_GRAY);
        txtMail.setForeground(Color.GREEN);
        txtMail.setFont(new Font("Serif", Font.PLAIN, 15));
        txtMail.setBounds(399, 121, 369, 27);
        panel_1.add(txtMail);
       
        txtPermisos = new JTextField("");
        txtPermisos.setEditable(false);
        txtPermisos.setBorder(null);
        txtPermisos.setBackground(Color.DARK_GRAY);
        txtPermisos.setForeground(Color.GREEN);
        txtPermisos.setFont(new Font("Serif", Font.PLAIN, 20));
        txtPermisos.setBounds(399, 163, 369, 27);
        panel_1.add(txtPermisos);
       
        txtEstado = new JTextField("");
        txtEstado.setEditable(false);
        txtEstado.setBorder(null);
        txtEstado.setBackground(Color.DARK_GRAY);
        txtEstado.setForeground(Color.GREEN);
        txtEstado.setFont(new Font("Serif", Font.PLAIN, 20));
        txtEstado.setBounds(399, 205, 369, 27);
        panel_1.add(txtEstado);
       
        JPanel panel_2 = new JPanel();
        panel_2.setBackground(Color.DARK_GRAY);
        panel_2.setBounds(290, 37, 478, 31);
        panel_1.add(panel_2);
       
        JPanel panel_2_1 = new JPanel();
        panel_2_1.setBackground(Color.DARK_GRAY);
        panel_2_1.setBounds(290, 79, 478, 31);
        panel_1.add(panel_2_1);
       
        JPanel panel_2_2 = new JPanel();
        panel_2_2.setBackground(Color.DARK_GRAY);
        panel_2_2.setBounds(290, 121, 478, 31);
        panel_1.add(panel_2_2);
       
        JPanel panel_2_3 = new JPanel();
        panel_2_3.setBackground(Color.DARK_GRAY);
        panel_2_3.setBounds(290, 163, 478, 31);
        panel_1.add(panel_2_3);
       
        JPanel panel_2_4 = new JPanel();
        panel_2_4.setBackground(Color.DARK_GRAY);
        panel_2_4.setBounds(290, 205, 478, 31);
        panel_1.add(panel_2_4);
       
        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		banear();
        		datos();
        		permisos();
        		pintar();
        	}
        });
        btnGuardar.setForeground(Color.GREEN);
        btnGuardar.setFont(new Font("Serif", Font.PLAIN, 20));
        btnGuardar.setFocusable(false);
        btnGuardar.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnGuardar.setBackground(Color.BLACK);
        btnGuardar.setBounds(485, 247, 180, 46);
        panel_1.add(btnGuardar);
        btnGuardar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnGuardar.setBackground(Color.GREEN);
                btnGuardar.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnGuardar.setBackground(Color.BLACK);
                btnGuardar.setForeground(Color.GREEN);
            }
        });
       
        JButton btnSalir = new JButton("Volver");
        btnSalir.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		dispose();
        		Administrar administrar = new Administrar();
				administrar.setVisible(true);
        	}
        });
        btnSalir.setBounds(689, 247, 79, 46);
        panel_1.add(btnSalir);
        btnSalir.setForeground(Color.GREEN);
        btnSalir.setFont(new Font("Serif", Font.PLAIN, 20));
        btnSalir.setFocusable(false);
        btnSalir.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnSalir.setBackground(Color.BLACK);
        btnSalir.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnSalir.setBackground(Color.GREEN);
                btnSalir.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnSalir.setBackground(Color.BLACK);
                btnSalir.setForeground(Color.GREEN);
            }
        });
    }

	protected void datos() {
		try {
			Connection conexion;
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando=conexion.createStatement();
			comando.executeUpdate("UPDATE `trivial`.`usuarios` SET `nick` = '" + txtNick.getText() + "' where nick like '" + txtBuscar.getText() + "';");
			comando.executeUpdate("UPDATE `trivial`.`usuarios` SET `pass` = '" + txtPass.getText() + "' where nick like '" + txtBuscar.getText() + "';");
			comando.executeUpdate("UPDATE `trivial`.`usuarios` SET `email` = '" + txtMail.getText() + "' where nick like '" + txtBuscar.getText() + "';");
			txtBuscar.setText(txtNick.getText());
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	protected void pintar() {
		try {
			Connection conexion;
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando=conexion.createStatement();
			ResultSet resultado = comando.executeQuery("select img_perfil.img from img_perfil join usuarios on img_perfil.id = usuarios.fk_img where nick like '"+txtBuscar.getText()+"';");
			resultado.next();
			String dato = resultado.getString(1);
			lblFoto.setIcon(new ImageIcon("assets/profile/"+dato));
			resultado = comando.executeQuery("select nick from usuarios where nick like '"+txtBuscar.getText()+"';");
			resultado.next();
			dato = resultado.getString(1);
			txtNick.setText(dato);
			resultado = comando.executeQuery("select pass from usuarios where nick like '"+txtBuscar.getText()+"';");
			resultado.next();
			dato = resultado.getString(1);
			txtPass.setText(dato);
			resultado = comando.executeQuery("select email from usuarios where nick like '"+txtBuscar.getText()+"';");
			resultado.next();
			dato = resultado.getString(1);
			txtMail.setText(dato);
			resultado = comando.executeQuery("select admin from usuarios where nick like '"+txtBuscar.getText()+"';");
			resultado.next();
			Boolean estado = resultado.getBoolean(1);
			if (estado) {
				chckAdmin.setSelected(true);
				txtPermisos.setText("Administrador");
			} else {
				chckAdmin.setSelected(false);
				txtPermisos.setText("Usuario");
			}
			resultado = comando.executeQuery("select baneado from usuarios where nick like '"+txtBuscar.getText()+"';");
			resultado.next();
			estado = resultado.getBoolean(1);
			if (!estado) {
				chckBan.setSelected(false);
				txtEstado.setText("Activo");
			} else {
				chckBan.setSelected(true);
				txtEstado.setText("Baneado");
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
	}

	protected void banear() {
		if (chckBan.isSelected()) {
			Connection conexion;
			try {
				conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
				Statement comando=conexion.createStatement();
				comando.executeUpdate("UPDATE `usuarios` SET `baneado` = '1' WHERE `usuarios`.`nick` like'"+txtBuscar.getText()+"';");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			Connection conexion;
			try {
				conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
				Statement comando=conexion.createStatement();
				comando.executeUpdate("UPDATE `usuarios` SET `baneado` = '0' WHERE `usuarios`.`nick` like'"+txtBuscar.getText()+"';");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	protected void permisos() {
		if (chckAdmin.isSelected()) {
			chckAdmin.setSelected(false);
			txtPermisos.setText("Usuario");
			Connection conexion;
			try {
				conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
				Statement comando=conexion.createStatement();
				comando.executeUpdate("UPDATE `usuarios` SET `admin` = '1' WHERE `usuarios`.`nick` like'"+txtBuscar.getText()+"';");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			chckAdmin.setSelected(true);
			txtPermisos.setText("Administrador");
			Connection conexion;
			try {
				conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
				Statement comando=conexion.createStatement();
				comando.executeUpdate("UPDATE `usuarios` SET `admin` = '0' WHERE `usuarios`.`nick` like'"+txtBuscar.getText()+"';");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
}