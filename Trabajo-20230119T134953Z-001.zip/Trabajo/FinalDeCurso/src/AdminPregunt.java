import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.Canvas;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JTextPane;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;

public class AdminPregunt extends JFrame {

    private JPanel contentPane;
    private static AdminPregunt frame;
    private JTextPane txtPregunta;
    private JTextField txtRes1;
    private JTextField txtRes2;
    private JTextField txtRes3;
    private JTextField txtRes4;
    private ButtonGroup rdbGrupo=new ButtonGroup();
    private int num=1;
    private int preg = 0;
    private JComboBox comboBox;
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    frame = new AdminPregunt();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public AdminPregunt() {
    	setTitle("Pregunta2");
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin-dam1b\\Desktop\\Trabajo\\FinalDeCurso\\assets\\logo.png"));
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 861, 465);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 0));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
       
        JPanel panel = new JPanel();
        panel.setBorder(new LineBorder(Color.GREEN, 2));
        panel.setBackground(Color.BLACK);
        panel.setBounds(10, 11, 825, 86);
        contentPane.add(panel);
        panel.setLayout(null);
       
        txtPregunta = new JTextPane();
        txtPregunta.setBackground(Color.DARK_GRAY);
        txtPregunta.setForeground(Color.GREEN);
        txtPregunta.setFont(new Font("Serif", Font.PLAIN, 11));
        txtPregunta.setBounds(77, 11, 671, 64);
        panel.add(txtPregunta);
       
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(Color.BLACK);
        panel_1.setBorder(new LineBorder(Color.GREEN, 2));
        panel_1.setBounds(10, 108, 825, 308);
        contentPane.add(panel_1);
        panel_1.setLayout(null);
       
        JLabel lblNewLabel = new JLabel("Respuesta correcta");
        lblNewLabel.setFont(new Font("Serif", Font.PLAIN, 20));
        lblNewLabel.setForeground(Color.GREEN);
        lblNewLabel.setBounds(10, 35, 167, 27);
        panel_1.add(lblNewLabel);
       
        JLabel lblRespuesta_2 = new JLabel("Respuesta 2");
        lblRespuesta_2.setFont(new Font("Serif", Font.PLAIN, 20));
        lblRespuesta_2.setForeground(Color.GREEN);
        lblRespuesta_2.setBounds(10, 89, 95, 27);
        panel_1.add(lblRespuesta_2);
       
        JLabel lblRespuesta_1 = new JLabel("Respuesta 3");
        lblRespuesta_1.setFont(new Font("Serif", Font.PLAIN, 20));
        lblRespuesta_1.setForeground(Color.GREEN);
        lblRespuesta_1.setBounds(10, 143, 95, 27);
        panel_1.add(lblRespuesta_1);
       
        JLabel lblRespuesta = new JLabel("Respuesta 4");
        lblRespuesta.setFont(new Font("Serif", Font.PLAIN, 20));
        lblRespuesta.setForeground(Color.GREEN);
        lblRespuesta.setBounds(10, 197, 95, 27);
        panel_1.add(lblRespuesta);
       
        txtRes1 = new JTextField();
        txtRes1.setBackground(Color.DARK_GRAY);
        txtRes1.setBorder(null);
        txtRes1.setForeground(Color.GREEN);
        txtRes1.setFont(new Font("Serif", Font.PLAIN, 11));
        txtRes1.setBounds(170, 35, 644, 27);
        panel_1.add(txtRes1);
        txtRes1.setColumns(10);
       
        txtRes2 = new JTextField();
        txtRes2.setBackground(Color.DARK_GRAY);
        txtRes2.setBorder(null);
        txtRes2.setForeground(Color.GREEN);
        txtRes2.setFont(new Font("Serif", Font.PLAIN, 11));
        txtRes2.setColumns(10);
        txtRes2.setBounds(170, 89, 644, 27);
        panel_1.add(txtRes2);
       
        txtRes3 = new JTextField();
        txtRes3.setBackground(Color.DARK_GRAY);
        txtRes3.setBorder(null);
        txtRes3.setForeground(Color.GREEN);
        txtRes3.setFont(new Font("Serif", Font.PLAIN, 11));
        txtRes3.setColumns(10);
        txtRes3.setBounds(170, 143, 644, 27);
        panel_1.add(txtRes3);
       
        txtRes4 = new JTextField();
        txtRes4.setBackground(Color.DARK_GRAY);
        txtRes4.setBorder(null);
        txtRes4.setForeground(Color.GREEN);
        txtRes4.setFont(new Font("Serif", Font.PLAIN, 11));
        txtRes4.setColumns(10);
        txtRes4.setBounds(170, 197, 644, 27);
        panel_1.add(txtRes4);
       
        JButton btnAnterior = new JButton("<");
        btnAnterior.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Connection conexion;
                ResultSet max;
				try {
	                conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
	                Statement id=conexion.createStatement();
					max = id.executeQuery("select max(id) from preguntas_respuestas;");
					max.next();
	                int maxId = max.getInt(1)-1;
	                if (num == 0) {
						num = maxId;
					}
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}

                try {
                    conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
                    Statement comando=conexion.createStatement();
                   
                    ResultSet resultado = comando.executeQuery("SELECT `pregunta` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    resultado.next();
                    String preg = resultado.getString(1);
                    txtPregunta.setText(preg);
                   
                    ResultSet resultado_1 = comando.executeQuery("SELECT `rcorrecta` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    resultado_1.next();
                    String res1 = resultado_1.getString(1);
                    txtRes1.setText(res1);
                   
                    ResultSet resultado_2 = comando.executeQuery("SELECT `rfalsa1` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    resultado_2.next();
                    String res2 = resultado_2.getString(1);
                    txtRes2.setText(res2);
                   
                    ResultSet resultado_3 = comando.executeQuery("SELECT `rfalsa2` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    resultado_3.next();
                    String res3 = resultado_3.getString(1);
                    txtRes3.setText(res3);
                   
                    ResultSet resultado_4 = comando.executeQuery("SELECT `rfalsa3` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    resultado_4.next();
                    String res4 = resultado_4.getString(1);
                    txtRes4.setText(res4);
                    
                    ResultSet tema = comando.executeQuery("SELECT `fk_tema` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    tema.next();
                    int temaa = tema.getInt(1);
                    comboBox.setSelectedIndex(temaa);
                    num --;
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
               
            }
				
        	
        });
        btnAnterior.setFont(new Font("Tahoma", Font.PLAIN, 43));
        btnAnterior.setBackground(Color.BLACK);
        btnAnterior.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnAnterior.setFocusable(false);
        btnAnterior.setForeground(Color.GREEN);
        btnAnterior.setBounds(10, 11, 64, 64);
        btnAnterior.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnAnterior.setBackground(Color.GREEN);
                btnAnterior.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnAnterior.setBackground(Color.BLACK);
                btnAnterior.setForeground(Color.GREEN);
            }
        });
        panel.add(btnAnterior);
       
        JButton btnSiguiente = new JButton(">");
        btnSiguiente.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Connection conexion;
                ResultSet max;
				try {
	                conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
	                Statement id=conexion.createStatement();
					max = id.executeQuery("select max(id) from preguntas_respuestas;");
					max.next();
	                int maxId = max.getInt(1);
	                if (num == maxId + 1) {
						num = 1;
					}
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}

                try {
                    conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
                    Statement comando=conexion.createStatement();
                   
                    ResultSet resultado = comando.executeQuery("SELECT `pregunta` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    resultado.next();
                    String preg = resultado.getString(1);
                    txtPregunta.setText(preg);
                   
                    ResultSet resultado_1 = comando.executeQuery("SELECT `rcorrecta` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    resultado_1.next();
                    String res1 = resultado_1.getString(1);
                    txtRes1.setText(res1);
                   
                    ResultSet resultado_2 = comando.executeQuery("SELECT `rfalsa1` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    resultado_2.next();
                    String res2 = resultado_2.getString(1);
                    txtRes2.setText(res2);
                   
                    ResultSet resultado_3 = comando.executeQuery("SELECT `rfalsa2` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    resultado_3.next();
                    String res3 = resultado_3.getString(1);
                    txtRes3.setText(res3);
                   
                    ResultSet resultado_4 = comando.executeQuery("SELECT `rfalsa3` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    resultado_4.next();
                    String res4 = resultado_4.getString(1);
                    txtRes4.setText(res4);
                    
                    ResultSet tema = comando.executeQuery("SELECT `fk_tema` FROM `preguntas_respuestas` WHERE `id` =" +num+";");
                    tema.next();
                    int temaa = tema.getInt(1);
                    comboBox.setSelectedIndex(temaa);
                    num ++;
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
               
            }
        });
        btnSiguiente.setBackground(Color.BLACK);
        btnSiguiente.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnSiguiente.setFocusable(false);
        btnSiguiente.setForeground(Color.GREEN);
        btnSiguiente.setFont(new Font("Tahoma", Font.PLAIN, 43));
        btnSiguiente.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnSiguiente.setBackground(Color.GREEN);
                btnSiguiente.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnSiguiente.setBackground(Color.BLACK);
                btnSiguiente.setForeground(Color.GREEN);
            }
        });
        btnSiguiente.setBounds(752, 11, 64, 64);
       
        panel.add(btnSiguiente);
           
        JButton btnInsertar = new JButton("Insertar");
        btnInsertar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Connection conexion;
                if (comboBox.getSelectedIndex()==0||txtPregunta.getText().equals("")||txtRes1.getText().equals("")||txtRes2.getText().equals("")||txtRes3.getText().equals("")||txtRes4.getText().equals("")) {
               
                    JOptionPane.showMessageDialog(null, "Rellene todos los campos", "Error", 2, null);
                   
                }else {
                    try {
                        conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
                        Statement comando=conexion.createStatement();
                        comando.executeUpdate("INSERT INTO `preguntas_respuestas`(`pregunta`, `rcorrecta`, `rfalsa1`, `rfalsa2`, `rfalsa3`, `fk_tema`) VALUES ('" + txtPregunta.getText() + "','" + txtRes1.getText() + "','" + txtRes2.getText() + "','" + txtRes3.getText() + "','" + txtRes4.getText() + "','" + (comboBox.getSelectedIndex()-1) + "');");
                        JOptionPane.showMessageDialog(null, "Pregunta insertada correctamente", "Inserci�n de preguntas", 1, null);
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                }
               
            }
        });
        btnInsertar.setFont(new Font("Serif", Font.PLAIN, 30));
        btnInsertar.setBackground(Color.BLACK);
        btnInsertar.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnInsertar.setFocusable(false);
        btnInsertar.setForeground(Color.GREEN);
        btnInsertar.setBounds(10, 235, 175, 54);
        btnInsertar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnInsertar.setBackground(Color.GREEN);
                btnInsertar.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnInsertar.setBackground(Color.BLACK);
                btnInsertar.setForeground(Color.GREEN);
            }
        });
        panel_1.add(btnInsertar);
       
       
        JButton btnEditar = new JButton("Editar");
        btnEditar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		Connection conexion;
                Statement comando;
        		try {
                    conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
                    comando=conexion.createStatement();
                    comando.executeUpdate("UPDATE `preguntas_respuestas` SET `pregunta`='" + txtPregunta.getText() + "',`rcorrecta`='" + txtRes1.getText() + "',`rfalsa1`='" + txtRes2.getText() + "',`rfalsa2`='" + txtRes3.getText() + "',`rfalsa3`='" + txtRes4.getText() + "',`fk_tema`='" + (comboBox.getSelectedIndex()-1) + "' WHERE id LIKE " + preg + ";");
                    JOptionPane.showMessageDialog(null, "Pregunta modificada correctamente", "Modificaci�n de preguntas", 1, null);
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
        	}
        });
        btnEditar.setBackground(Color.BLACK);
        btnEditar.setFocusable(false);
        btnEditar.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnEditar.setForeground(Color.GREEN);
        btnEditar.setFont(new Font("Serif", Font.PLAIN, 30));
        btnEditar.setBounds(198, 235, 175, 54);
        btnEditar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnEditar.setBackground(Color.GREEN);
                btnEditar.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnEditar.setBackground(Color.BLACK);
                btnEditar.setForeground(Color.GREEN);
            }
        });
        panel_1.add(btnEditar);
       
        JButton btnBorrar = new JButton("Borrar");
        btnBorrar.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
				try {
	        		Connection conexion;
	        		conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
	                Statement comando = conexion.createStatement();
	                comando.executeUpdate("DELETE FROM `preguntas_respuestas` WHERE pregunta like '" + txtPregunta.getText() + "';");
	                JOptionPane.showMessageDialog(null, "Pregunta Eliminada correctamente", "Borrado de preguntas", 1, null);
	                txtPregunta.setText("");
	                txtRes1.setText("");
	                txtRes2.setText("");
	                txtRes3.setText("");
	                txtRes4.setText("");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	}
        });
        btnBorrar.setBackground(Color.BLACK);
        btnBorrar.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnBorrar.setFocusable(false);
        btnBorrar.setForeground(Color.GREEN);
        btnBorrar.setFont(new Font("Serif", Font.PLAIN, 30));
        btnBorrar.setBounds(386, 235, 175, 54);
        btnBorrar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnBorrar.setBackground(Color.GREEN);
                btnBorrar.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnBorrar.setBackground(Color.BLACK);
                btnBorrar.setForeground(Color.GREEN);
            }
        });
        panel_1.add(btnBorrar);
       
        comboBox = new JComboBox();
        comboBox.setBackground(Color.BLACK);
        comboBox.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        comboBox.setFocusable(false);
        comboBox.setForeground(Color.GREEN);
        comboBox.setFont(new Font("Serif", Font.PLAIN, 15));
        comboBox.setBounds(576, 262, 108, 27);
        comboBox.addItem("");
        comboBox.addItem("Ciencia");
        comboBox.addItem("Deporte");
        comboBox.addItem("Historia");
        comboBox.addItem("Geografia");
        comboBox.addItem("Cultura");
        comboBox.addItem("Entretenimiento");
        panel_1.add(comboBox);
       
        JLabel lblTema = new JLabel("Tema");
        lblTema.setForeground(Color.GREEN);
        lblTema.setFont(new Font("Serif", Font.PLAIN, 20));
        lblTema.setBounds(596, 235, 44, 27);
        panel_1.add(lblTema);
       
        JButton btnAtras = new JButton("Volver");
        btnAtras.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                Administrar administrar = new Administrar();
                administrar.setVisible(true);
            }
        });
        btnAtras.setForeground(Color.GREEN);
        btnAtras.setFont(new Font("Serif", Font.PLAIN, 30));
        btnAtras.setFocusable(false);
        btnAtras.setBorder(new LineBorder(new Color(0, 255, 0), 2));
        btnAtras.setBackground(Color.BLACK);
        btnAtras.setBounds(694, 236, 120, 54);
        btnAtras.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                btnAtras.setBackground(Color.GREEN);
                btnAtras.setForeground(Color.BLACK);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                btnAtras.setBackground(Color.BLACK);
                btnAtras.setForeground(Color.GREEN);
            }
        });
        panel_1.add(btnAtras);
    }
}