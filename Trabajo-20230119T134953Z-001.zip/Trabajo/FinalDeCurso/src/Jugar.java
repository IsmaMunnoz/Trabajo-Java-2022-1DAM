import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.concurrent.TimeUnit;

import javax.swing.JTextPane;
import javax.swing.JProgressBar;

public class Jugar extends JFrame {

	private JPanel contentPane;
	private static Jugar frame;
	private StyledDocument doc;
	private JTextPane txtPregunta, txtRojo, txtAzul, txtAmarillo, txtVerde;
	private SimpleAttributeSet center;
	private JLabel lblTema;
	private ResultSet rcorrect;
	private JPanel panel_aciertos;
	private JLabel lblAciertos;
	private JProgressBar progressBar;
	private String preg, ans, img;
	private String bien, mal1, mal2, mal3;
	private int i = 1;
	private int idMax;
	int aciertos = 0;
	private int[] arrPreguntas = {0,0,0,0,0,0,0,0,0,0,0};
	private int[] arrRespuestas = {0,0,0,0};
	private JLabel lblTotal;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Jugar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Jugar() {
		setTitle("Pregunta2");
		try {
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando = conexion.createStatement();
			ResultSet idmax = comando.executeQuery("select max(id) from preguntas_respuestas;");
			idmax.next();
			idMax = idmax.getInt(1);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for(int i=0;i<arrPreguntas.length;i++){
            boolean encontrado = false;
            int ale=(int)(Math.random()*idMax)+1;
            for (int j=0;j<i ;j++){
                if(arrPreguntas[j]==ale){
                    encontrado=true;
                }
            }
            if(!encontrado){
                arrPreguntas[i]=ale;
            }else{
                i--;
            }
        }
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin-dam1b\\Desktop\\Trabajo\\FinalDeCurso\\assets\\logo.png"));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1216, 715);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(239, 184, 16));
		panel.setBounds(0, 0, 1200, 128);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(239, 184, 16));
		panel_1.setBounds(189, 11, 822, 110);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("2");
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBounds(741, -11, 79, 132);
		panel_1.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Curlz MT", Font.BOLD, 99));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblNewLabel_1 = new JLabel("PREGUNTA");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setBounds(36, 11, 695, 132);
		panel_1.add(lblNewLabel_1);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Ravie", Font.PLAIN, 99));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 51, 102));
		panel_2.setBounds(0, 122, 1200, 554);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(0, 75, 150));
		panel_3.setBounds(150, 62, 900, 434);
		panel_2.add(panel_3);
		panel_3.setLayout(null);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(102, 153, 204));
		panel_4.setBounds(10, 10, 880, 90);
		panel_3.add(panel_4);
		panel_4.setLayout(null);
		
		txtPregunta = new JTextPane();
		txtPregunta.setBackground(new Color(102, 153, 204));
		txtPregunta.setEditable(false);
		txtPregunta.setForeground(Color.BLACK);
		txtPregunta.setFont(new Font("HP Simplified", Font.BOLD, 16));
		try {
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando = conexion.createStatement();
			ResultSet question = comando.executeQuery("select pregunta from preguntas_respuestas where id = " + arrPreguntas[0] + ";");
			question.next();
			preg = question.getString(1);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		txtPregunta.setText(preg);
		txtPregunta.setBounds(40, 11, 800, 68);
		panel_4.add(txtPregunta);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBounds(10, 111, 880, 312);
		panel_3.add(panel_5);
		panel_5.setLayout(null);
		
		txtRojo = new JTextPane();
		txtRojo.setForeground(Color.BLACK);
		txtRojo.setFont(new Font("HP Simplified", Font.BOLD, 16));
		try {
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando = conexion.createStatement();
			ResultSet rcorrect = comando.executeQuery("select rcorrecta from preguntas_respuestas where id = " + arrPreguntas[0] + ";");
			rcorrect.next();
			bien = rcorrect.getString(1);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		txtRojo.setText(bien);
		txtRojo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (txtRojo.getText().equals(bien)) {
					aciertos++;
					lblAciertos.setText(String.valueOf(aciertos));
					progressBar.setValue(aciertos*10);
				}
				jugar();
				try {
		            Connection conexion;
		            conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
		            Statement comando=conexion.createStatement();
		            ResultSet resultado = comando.executeQuery("select tema.img from tema join preguntas_respuestas on tema.id = preguntas_respuestas.fk_tema where preguntas_respuestas.pregunta like '" + txtPregunta + "';");
		            resultado.next();
		            img = String.valueOf(resultado);
		            lblTema.setIcon(new ImageIcon("assets/temas/" + img));
		        } catch (SQLException e1) {
		            // TODO Auto-generated catch block
		            e1.printStackTrace();
		        }
				if (i < 10) {
					i++;
				} else if (i == 10){
					try {
			            Connection conexion;
			            conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			            Statement comando=conexion.createStatement();
			            ResultSet id = comando.executeQuery("select max(id) from partidas");
			            id.next();
			            int mId = id.getInt(1);
			            ResultSet player = comando.executeQuery("select id from usuarios where nick like '" + LogIn.user + "';");
			            player.next();
			            int playerId = player.getInt(1);
			            comando.executeUpdate("INSERT INTO `trivial`.`leaderboard`(`puntuacion`, `fk_partida`, `fk_jugador`) VALUES ('" + aciertos + "', '" + mId + "', '" + playerId + "');");
			        } catch (SQLException e1) {
			            // TODO Auto-generated catch block
			            e1.printStackTrace();
			        }
					panel_3.setVisible(false);
					panel_aciertos.setVisible(true);
				}
			}
		});
		txtRojo.setEditable(false);
		txtRojo.setBackground(new Color(255, 10, 10));
		txtRojo.setBounds(30, 30, 395, 118);
		panel_5.add(txtRojo);
		
		txtAzul = new JTextPane();
		txtAzul.setForeground(Color.BLACK);
		txtAzul.setFont(new Font("HP Simplified", Font.BOLD, 16));
		try {
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando = conexion.createStatement();
			ResultSet rfalsa1 = comando.executeQuery("select rfalsa1 from preguntas_respuestas where id = " + arrPreguntas[0] + ";");
			rfalsa1.next();
			mal1 = rfalsa1.getString(1);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		txtAzul.setText(mal1);
		txtAzul.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (txtAzul.getText().equals(bien)) {
					aciertos++;
					lblAciertos.setText(String.valueOf(aciertos));
					progressBar.setValue(aciertos*10);
				}
				jugar();
				try {
		            Connection conexion;
		            conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
		            Statement comando=conexion.createStatement();
		            ResultSet resultado = comando.executeQuery("select tema.img from tema join preguntas_respuestas on tema.id = preguntas_respuestas.fk_tema where preguntas_respuestas.pregunta like '" + txtPregunta + "';");
		            resultado.next();
		            img = String.valueOf(resultado);
		            lblTema.setIcon(new ImageIcon("assets/temas/" + img));
		        } catch (SQLException e1) {
		            // TODO Auto-generated catch block
		            e1.printStackTrace();
		        }
				if (i < 10) {
					i++;
				} else if (i == 10){
					try {
			            Connection conexion;
			            conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			            Statement comando=conexion.createStatement();
			            ResultSet id = comando.executeQuery("select max(id) from partidas");
			            id.next();
			            int mId = id.getInt(1);
			            ResultSet player = comando.executeQuery("select id from usuarios where nick like '" + LogIn.user + "';");
			            player.next();
			            int playerId = player.getInt(1);
			            comando.executeUpdate("INSERT INTO `trivial`.`leaderboard`(`puntuacion`, `fk_partida`, `fk_jugador`) VALUES ('" + aciertos + "', '" + mId + "', '" + playerId + "');");
			        } catch (SQLException e1) {
			            // TODO Auto-generated catch block
			            e1.printStackTrace();
			        }
					panel_3.setVisible(false);
					panel_aciertos.setVisible(true);
				}
			}
		});
		txtAzul.setEditable(false);
		txtAzul.setBackground(new Color(0, 102, 255));
		txtAzul.setBounds(455, 30, 395, 118);
		panel_5.add(txtAzul);
		
		txtAmarillo = new JTextPane();
		txtAmarillo.setForeground(Color.BLACK);
		txtAmarillo.setFont(new Font("HP Simplified", Font.BOLD, 16));
		try {
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando = conexion.createStatement();
			ResultSet rfalsa3 = comando.executeQuery("select rfalsa3 from preguntas_respuestas where id = " + arrPreguntas[0] + ";");
			rfalsa3.next();
			mal3 = rfalsa3.getString(1);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		txtAmarillo.setText(mal3);
		txtAmarillo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (txtAmarillo.getText().equals(bien)) {
					aciertos++;
					lblAciertos.setText(String.valueOf(aciertos));
					progressBar.setValue(aciertos*10);
				}
				jugar();
				try {
		            Connection conexion;
		            conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
		            Statement comando=conexion.createStatement();
		            ResultSet resultado = comando.executeQuery("select tema.img from tema join preguntas_respuestas on tema.id = preguntas_respuestas.fk_tema where preguntas_respuestas.pregunta like '" + txtPregunta + "';");
		            resultado.next();
		            img = String.valueOf(resultado);
		            lblTema.setIcon(new ImageIcon("assets/temas/" + img));
		        } catch (SQLException e1) {
		            // TODO Auto-generated catch block
		            e1.printStackTrace();
		        }
				if (i < 10) {
					i++;
				} else if (i == 10){
					try {
			            Connection conexion;
			            conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			            Statement comando=conexion.createStatement();
			            ResultSet id = comando.executeQuery("select max(id) from partidas");
			            id.next();
			            int mId = id.getInt(1);
			            ResultSet player = comando.executeQuery("select id from usuarios where nick like '" + LogIn.user + "';");
			            player.next();
			            int playerId = player.getInt(1);
			            comando.executeUpdate("INSERT INTO `trivial`.`leaderboard`(`puntuacion`, `fk_partida`, `fk_jugador`) VALUES ('" + aciertos + "', '" + mId + "', '" + playerId + "');");
			        } catch (SQLException e1) {
			            // TODO Auto-generated catch block
			            e1.printStackTrace();
			        }
					panel_3.setVisible(false);
					panel_aciertos.setVisible(true);
				}
			}
		});
		txtAmarillo.setEditable(false);
		txtAmarillo.setBackground(new Color(255, 220, 0));
		txtAmarillo.setBounds(30, 163, 395, 118);
		panel_5.add(txtAmarillo);
		
		txtVerde = new JTextPane();
		txtVerde.setForeground(Color.BLACK);
		txtVerde.setFont(new Font("HP Simplified", Font.BOLD, 16));
		try {
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando = conexion.createStatement();
			ResultSet rfalsa2 = comando.executeQuery("select rfalsa2 from preguntas_respuestas where id = " + arrPreguntas[0] + ";");
			rfalsa2.next();
			mal2 = rfalsa2.getString(1);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		txtVerde.setText(mal2);
		txtVerde.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (txtVerde.getText().equals(bien)) {
					aciertos++;
					lblAciertos.setText(String.valueOf(aciertos));
					progressBar.setValue(aciertos*10);
				}
				jugar();
				try {
		            Connection conexion;
		            conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
		            Statement comando=conexion.createStatement();
		            ResultSet resultado = comando.executeQuery("select tema.img from tema join preguntas_respuestas on tema.id = preguntas_respuestas.fk_tema where preguntas_respuestas.pregunta like '" + txtPregunta + "';");
		            resultado.next();
		            img = String.valueOf(resultado);
		            lblTema.setIcon(new ImageIcon("assets/temas/" + img));
		        } catch (SQLException e1) {
		            // TODO Auto-generated catch block
		            e1.printStackTrace();
		        }
				if (i < 10) {
					i++;
				} else if (i == 10){
					try {
			            Connection conexion;
			            conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			            Statement comando=conexion.createStatement();
			            ResultSet id = comando.executeQuery("select max(id) from partidas");
			            id.next();
			            int mId = id.getInt(1);
			            ResultSet player = comando.executeQuery("select id from usuarios where nick like '" + LogIn.user + "';");
			            player.next();
			            int playerId = player.getInt(1);
			            comando.executeUpdate("INSERT INTO `trivial`.`leaderboard`(`puntuacion`, `fk_partida`, `fk_jugador`) VALUES ('" + aciertos + "', '" + mId + "', '" + playerId + "');");
			        } catch (SQLException e1) {
			            // TODO Auto-generated catch block
			            e1.printStackTrace();
			        }
					panel_3.setVisible(false);
					panel_aciertos.setVisible(true);
				}
			}
		});
		txtVerde.setEditable(false);
		txtVerde.setBackground(new Color(0, 204, 51));
		txtVerde.setBounds(455, 163, 395, 118);
		panel_5.add(txtVerde);
		
        lblTema = new JLabel("");
        lblTema.setIcon(new ImageIcon(""));
        lblTema.setBounds(1093, 34, 64, 145);
        panel_2.add(lblTema);
		
		panel_aciertos = new JPanel();
		panel_aciertos.setVisible(false);
        panel_aciertos.setBackground(new Color(0, 75, 150));
        panel_aciertos.setBounds(150, 62, 900, 434);
        panel_2.add(panel_aciertos);
        panel_aciertos.setLayout(null);
       
        lblAciertos = new JLabel("");
        lblAciertos.setForeground(Color.BLACK);
        lblAciertos.setHorizontalAlignment(SwingConstants.RIGHT);
        lblAciertos.setFont(new Font("HP Simplified", Font.PLAIN, 99));
        lblAciertos.setBounds(108, 93, 108, 120);
        panel_aciertos.add(lblAciertos);
       
        JLabel lblTotal;
        lblTotal = new JLabel("/10");
        lblTotal.setForeground(Color.BLACK);
        lblTotal.setFont(new Font("HP Simplified", Font.PLAIN, 99));
        lblTotal.setBounds(219, 93, 173, 120);
        panel_aciertos.add(lblTotal);
       
        JLabel lblNewLabel_2 = new JLabel("ACIERTOS");
        lblNewLabel_2.setForeground(Color.BLACK);
        lblNewLabel_2.setFont(new Font("HP Simplified Hans", Font.PLAIN, 99));
        lblNewLabel_2.setBounds(387, 93, 415, 113);
        panel_aciertos.add(lblNewLabel_2);
       
        progressBar = new JProgressBar();
        progressBar.setForeground(new Color(0, 51, 204));
        progressBar.setBackground(Color.WHITE);
        progressBar.setBounds(238, 239, 415, 43);
        progressBar.setValue(0);
        panel_aciertos.add(progressBar);
		
        JButton btnVolver = new JButton("VOLVER");
        btnVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (LogIn.var) {
                	dispose();
                    InicioAdmin inicioAdmin = new InicioAdmin();
                    inicioAdmin.setVisible(true);
                } else {
                    dispose();
                    InicioUser inicioUser = new InicioUser();
                    inicioUser.setVisible(true);
                }
            }
        });
        btnVolver.setFont(new Font("HP Simplified", Font.PLAIN, 20));
        btnVolver.setBounds(782, 380, 108, 43);
        panel_aciertos.add(btnVolver);
        
	}
	
	public void jugar() {
		for(int k=0;k<arrRespuestas.length;k++){
            boolean encontrado = false;
            int ale=(int)(Math.random()*4)+1;
            for (int j=0;j<k ;j++){
                if(arrRespuestas[j]==ale){
                    encontrado=true;
                }
            }
            if(!encontrado){
                arrRespuestas[k]=ale;
            }else{
                k--;
            }
            try {
    			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
    			Statement comando = conexion.createStatement();
    			ResultSet question = comando.executeQuery("select pregunta from preguntas_respuestas where id = " + arrPreguntas[i] + ";");
    			question.next();
    			preg = question.getString(1);
    		} catch (SQLException e1) {
    			// TODO Auto-generated catch block
    			e1.printStackTrace();
    		}
            txtPregunta.setText(preg);
        }
		
		try {
			Connection conexion;
			conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
			Statement comando=conexion.createStatement();
			rcorrect = comando.executeQuery("select rcorrecta from preguntas_respuestas where id = " + arrPreguntas[i] + ";");
			rcorrect.next();
			bien = rcorrect.getString(1);
			ResultSet rfalsa1 = comando.executeQuery("select rfalsa1 from preguntas_respuestas where id = " + arrPreguntas[i] + ";");
			rfalsa1.next();
			mal1 = rfalsa1.getString(1);
			ResultSet rfalsa2 = comando.executeQuery("select rfalsa2 from preguntas_respuestas where id = " + arrPreguntas[i] + ";");
			rfalsa2.next();
			mal2 = rfalsa2.getString(1);
			ResultSet rfalsa3 = comando.executeQuery("select rfalsa3 from preguntas_respuestas where id = " + arrPreguntas[i] + ";");
			rfalsa3.next();
			mal3 = rfalsa3.getString(1);
			asigRes();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void asigRes() {
		if (arrRespuestas[0] == 1) {
			txtRojo.setText(bien);
			if (arrRespuestas[1] == 2) {
				txtVerde.setText(mal1);
				if (arrRespuestas[2] == 3) {
					txtAmarillo.setText(mal2);
					txtAzul.setText(mal3);
				} else if (arrRespuestas[2] == 4) {
					txtAzul.setText(mal2);
					txtAmarillo.setText(mal3);
				}
			} else if (arrRespuestas[1] == 3) {
				txtAmarillo.setText(mal1);
				if (arrRespuestas[2] == 2) {
					txtVerde.setText(mal2);
					txtAzul.setText(mal3);
				} else if (arrRespuestas[2] == 4) {
					txtAzul.setText(mal2);
					txtVerde.setText(mal3);
				}
			} else if (arrRespuestas[1] == 4) {
				txtAzul.setText(mal1);
				if (arrRespuestas[2] == 3) {
					txtAmarillo.setText(mal2);
					txtVerde.setText(mal3);
				} else if (arrRespuestas[2] == 2) {
					txtVerde.setText(mal2);
					txtAmarillo.setText(mal3);
				}
			}
		} else if(arrRespuestas[0] == 2){
			txtVerde.setText(bien);
			if (arrRespuestas[1] == 1) {
				txtRojo.setText(mal1);
				if (arrRespuestas[2] == 3) {
					txtAmarillo.setText(mal2);
					txtAzul.setText(mal3);
				} else if (arrRespuestas[2] == 4) {
					txtAzul.setText(mal2);
					txtAmarillo.setText(mal3);
				}
			} else if (arrRespuestas[1] == 3) {
				txtAmarillo.setText(mal1);
				if (arrRespuestas[2] == 1) {
					txtRojo.setText(mal2);
					txtAzul.setText(mal3);
				} else if (arrRespuestas[2] == 4) {
					txtRojo.setText(mal3);
					txtAzul.setText(mal2);
				}
			} else if (arrRespuestas[1] == 4) {
				txtAzul.setText(mal1);
				if (arrRespuestas[2] == 1) {
					txtRojo.setText(mal2);
					txtAmarillo.setText(mal3);
				} else if (arrRespuestas[2] == 3) {
					txtRojo.setText(mal3);
					txtAmarillo.setText(mal2);
				}
			}
		} else if(arrRespuestas[0] == 3) {
			txtAmarillo.setText(bien);
			if (arrRespuestas[1] == 2) {
				txtVerde.setText(mal1);
				if (arrRespuestas[2] == 1) {
					txtRojo.setText(mal2);
					txtAzul.setText(mal3);
				} else if (arrRespuestas[2] == 4) {
					txtRojo.setText(mal3);
					txtAzul.setText(mal2);
				}
			} else if (arrRespuestas[1] == 1) {
				txtRojo.setText(mal1);
				if (arrRespuestas[2] == 2) {
					txtVerde.setText(mal2);
					txtAzul.setText(mal3);
				} else if (arrRespuestas[2] == 4) {
					txtVerde.setText(mal3);
					txtAzul.setText(mal2);
				}
			} else if (arrRespuestas[1] == 4) {
				txtAzul.setText(mal1);
				if (arrRespuestas[2] == 1) {
					txtRojo.setText(mal2);
					txtVerde.setText(mal3);
				} else if (arrRespuestas[2] == 2) {
					txtRojo.setText(mal3);
					txtVerde.setText(mal2);
				}
			}
		} else if (arrRespuestas[0] == 4) {
			txtAzul.setText(bien);
			if (arrRespuestas[1] == 2) {
				txtVerde.setText(mal1);
				if (arrRespuestas[2] == 1) {
					txtRojo.setText(mal2);
					txtAmarillo.setText(mal3);
				} else if (arrRespuestas[2] == 3) {
					txtRojo.setText(mal3);
					txtAmarillo.setText(mal2);
				}
			} else if (arrRespuestas[1] == 3) {
				txtAmarillo.setText(mal1);
				if (arrRespuestas[2] == 1) {
					txtRojo.setText(mal2);
					txtVerde.setText(mal3);
				} else if (arrRespuestas[2] == 2) {
					txtRojo.setText(mal3);
					txtVerde.setText(mal2);
				}{

				}
			} else if (arrRespuestas[1] == 1) {
				txtRojo.setText(mal1);
				if (arrRespuestas[2] == 2) {
					txtVerde.setText(mal2);
					txtAmarillo.setText(mal3);
				} else if (arrRespuestas[2] == 3) {
					txtVerde.setText(mal3);
					txtAmarillo.setText(mal2);
				}
			}
		}
	}
	
}
