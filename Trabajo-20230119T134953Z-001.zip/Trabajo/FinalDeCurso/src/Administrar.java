import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import java.awt.Canvas;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Toolkit;

public class Administrar extends JFrame {

    private JPanel contentPane;
    private static Administrar frame;
    static JLabel lblUser;
    static int volver;
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    frame = new Administrar();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Administrar() {
    	setTitle("Pregunta2");
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\admin-dam1b\\Desktop\\Trabajo\\FinalDeCurso\\assets\\logo.png"));
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1216, 715);
        setLocationRelativeTo(null);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
       
        JPanel panel = new JPanel();
        panel.setBackground(new Color(239, 184, 16));
        panel.setBounds(0, 0, 1200, 128);
        contentPane.add(panel);
        panel.setLayout(null);
       
        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(239, 184, 16));
        panel_1.setBounds(77, 11, 822, 110);
        panel.add(panel_1);
        panel_1.setLayout(null);
       
        JLabel lblNewLabel = new JLabel("2");
        lblNewLabel.setForeground(new Color(0, 0, 0));
        lblNewLabel.setBounds(741, -11, 79, 132);
        panel_1.add(lblNewLabel);
        lblNewLabel.setFont(new Font("Curlz MT", Font.BOLD, 99));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
       
        JLabel lblNewLabel_1 = new JLabel("PREGUNTA");
        lblNewLabel_1.setForeground(new Color(0, 0, 0));
        lblNewLabel_1.setBounds(36, 11, 695, 132);
        panel_1.add(lblNewLabel_1);
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setFont(new Font("Ravie", Font.PLAIN, 99));
       
        JLabel lblNewLabel_2 = new JLabel("ADMINISTRADOR");
        lblNewLabel_2.setForeground(new Color(0, 0, 0));
        lblNewLabel_2.setFont(new Font("Ravie", Font.PLAIN, 20));
        lblNewLabel_2.setBounds(906, 87, 252, 30);
        panel.add(lblNewLabel_2);
       
        JPanel panel_2 = new JPanel();
        panel_2.setBackground(new Color(0, 51, 102));
        panel_2.setBounds(0, 122, 1200, 554);
        contentPane.add(panel_2);
        panel_2.setLayout(null);
       
        JPanel panel_3 = new JPanel();
        panel_3.setBorder(new LineBorder(new Color(0, 0, 0), 2));
        panel_3.setBounds(1115, 11, 75, 76);
        panel.add(panel_3);
       
        JLabel lblProfile = new JLabel("");
        panel_3.add(lblProfile);
        try {
            Connection conexion;
            conexion = DriverManager.getConnection("jdbc:mysql://localhost/trivial?useSSL=false","root" ,"1234");
            Statement comando=conexion.createStatement();
            ResultSet resultado = comando.executeQuery("select img_perfil.img from img_perfil join usuarios on img_perfil.id = usuarios.fk_img where nick like '"+LogIn.user+"';");
            resultado.next();
            String img = resultado.getString(1);
            lblProfile.setIcon(new ImageIcon("assets/user/"+img));
        } catch (SQLException e1) {
            lblProfile.setIcon(new ImageIcon("/assets/user/1.png"));
            e1.printStackTrace();
        }
       
        JLabel lblNewLabel_21 = new JLabel("User: ");
        lblNewLabel_21.setForeground(Color.WHITE);
        lblNewLabel_21.setBounds(10, 529, 46, 14);
        panel_2.add(lblNewLabel_21);
       
        lblUser = new JLabel("");
        lblUser.setText(LogIn.user);
        lblUser.setForeground(Color.WHITE);
        lblUser.setBounds(47, 530, 145, 14);
        panel_2.add(lblUser);
       
        JButton btnAdminUser = new JButton("Administrar usuarios");
        btnAdminUser.setForeground(Color.BLACK);
        btnAdminUser.setFocusable(false);
        btnAdminUser.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                AdminUser adminUser = new AdminUser();
                adminUser.setVisible(true);
            }
        });

		btnAdminUser.setFont(new Font("Ravie", Font.PLAIN, 25));
        btnAdminUser.setBounds(350, 66, 500, 131);
        btnAdminUser.setBackground(new Color(255, 255, 180));
        btnAdminUser.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnAdminUser.setBackground(new Color(239, 184, 16));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnAdminUser.setBackground(new Color(255, 255, 180));
			}
		});
        panel_2.add(btnAdminUser);
       
        JButton btnAdministrarPreguntas = new JButton("Administrar preguntas");
        btnAdministrarPreguntas.setForeground(Color.BLACK);
        btnAdministrarPreguntas.setFocusable(false);
        btnAdministrarPreguntas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                AdminPregunt adminPregunt = new AdminPregunt();
                adminPregunt.setVisible(true);
            }
        });
        btnAdministrarPreguntas.setFont(new Font("Ravie", Font.PLAIN, 25));
        btnAdministrarPreguntas.setBounds(350, 208, 500, 131);
        btnAdministrarPreguntas.setBackground(new Color(255, 255, 180));
        btnAdministrarPreguntas.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnAdministrarPreguntas.setBackground(new Color(239, 184, 16));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnAdministrarPreguntas.setBackground(new Color(255, 255, 180));
			}
		});
        panel_2.add(btnAdministrarPreguntas);
       
        JButton btnReiniciar = new JButton("Reiniciar");
        btnReiniciar.setForeground(Color.BLACK);
        btnReiniciar.setFocusable(false);
        btnReiniciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                AdminReiniciar adminReiniciar = new AdminReiniciar();
                adminReiniciar.setVisible(true);
            }
        });
        btnReiniciar.setFont(new Font("Ravie", Font.PLAIN, 40));
        btnReiniciar.setBackground(new Color(255, 255, 180));
        btnReiniciar.setBounds(350, 350, 500, 131);
        btnReiniciar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				btnReiniciar.setBackground(new Color(239, 184, 16));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				btnReiniciar.setBackground(new Color(255, 255, 180));
			}
		});
        panel_2.add(btnReiniciar);
        
        JLabel lblAtras = new JLabel("");
		lblAtras.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				InicioAdmin inicioadmin = new InicioAdmin();
				inicioadmin.setVisible(true);
				dispose();
			}
		});
		lblAtras.setBounds(10, 468, 50, 50);
		lblAtras.setIcon(new ImageIcon("assets/volver.png"));
		
		panel_2.add(lblAtras);
    }
}